package Assisted_practice_project2;

public class ThrowDemo {
	
	public void div(int a , int b)
	{
		if (b==0)
		{
			throw new ArithmeticException();
		}
		else
		{
			int c = a/b;
			System.out.println(c);
			
		}
	}


	public static void main(String[] args) {
	

		ThrowDemo obj = new ThrowDemo();
		obj.div(14, 0); 

	}

}
