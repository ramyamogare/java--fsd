package Assisted_practice_project2.collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapDemo {
	
	

	public static void main(String[] args) {
	
		
		HashMap<String,Integer> hm = new HashMap<>();
		
		hm.put("Ravi", 5678); 
		hm.put("Ram", 6789);
		hm.put("Raghu", 5845);
		hm.put("Jayathreeth", 5395);
		hm.put("Jayalaxmi", 34535);
		
		
		
		
		Set set = hm.entrySet();
		
		
		Iterator itr = set.iterator();
		while(itr.hasNext())
		{
		System.out.println(itr.next());
		}
		
	
		
		hm.remove("Marc");
	}
}