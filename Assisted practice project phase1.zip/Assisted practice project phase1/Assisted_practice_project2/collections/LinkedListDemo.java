package Assisted_practice_project2.collections;

import java.util.LinkedList;

import javax.swing.text.html.HTMLDocument.Iterator;

public class LinkedListDemo {

	public static void main(String[] args) {
	
		LinkedList<String> cities = new LinkedList<>();
		cities.add("Kalaburgi");
		cities.add("Banglore");
		cities.add(2, "Hubli");
		cities.add("Bijapur");
		System.out.println(cities.size());
		java.util.Iterator<String> itr = cities.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		System.out.println(cities.get(1));
		System.out.println();

	}

}
