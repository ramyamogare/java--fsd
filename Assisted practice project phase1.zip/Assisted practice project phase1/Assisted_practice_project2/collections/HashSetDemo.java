package Assisted_practice_project2.collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class HashSetDemo {

	public static void main(String[] args) {
	
HashSet<String> cities = new HashSet<>();
		
		cities.add("Kalaburgi");
		cities.add("Banglore");
		cities.add("Hubli");
		cities.add("Bijapur");
		cities.add("Chitapura");
		cities.add("Mysore");
		
		
		for (String t: cities)
		{
			System.out.println(t);
		}


		
		System.out.println(cities.size());
		
		
		
		System.out.println(cities.contains("Hyderabad")); 
		
		
	}

}

