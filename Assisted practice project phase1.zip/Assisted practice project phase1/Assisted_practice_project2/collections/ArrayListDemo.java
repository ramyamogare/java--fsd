package Assisted_practice_project2.collections;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		
	
		
		ArrayList<String> cities = new ArrayList<>();
		//checking add() method
		cities.add("Kalaburgi");
		cities.add("Banglore");
		cities.add("Hubli");
		cities.add("Bijapur");
		//size of array
		System.out.println(cities.size());
		//print item in list
		for(String t:cities){
			System.out.println(t);
			}
	}
}

