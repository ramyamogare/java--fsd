package Assisted_practice_project2;

public class ExceptionDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i = 9;
		int j = 0;
		
	try {
		System.out.println("result" + i / j);
	}
	catch(ArithmeticException e){
		System.out.println(e);
		
	}
		
		System.out.println(" multiplication : " + i * j);
		System.out.println("addidtion : " + i + j);
		System.out.println("substraction : " + (i - j));

	}

}
