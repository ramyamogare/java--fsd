package Assisted_practice_project2;

public class Access1 {

	
	//Access modifiers, lets us give access to one file data to other files and packages in a project
	
	// Types of modifiers
	// 1. default , 2. public, 3. Protected, 4. Private
	
	// create 2 variables below.
	// we did not mention any modifier to below variables, so they have default modifer.
	// Save the file and lets access these variables from Access2 class.
	
	int hours =3;
	int mins = 47;
	
	// Scenario 2: Public Modifier
	// create 2 variables below and add public modifier before it.
	// Save the file and lets access these variables from Access2 class and Access3 class
	
	public String name = "sonal";
	public String tool = "Selenium";
	
	// Scenario 3: private Modifier
		// create 2 variables below and add private modifier before it.
		// Save the file and lets access these variables from Access2 class and Access3 class
	   // you will not be able to access, as variables are private
	// we can call the variables in current class only
	private int a =3;
	private int b = 47;
	
	// Scenario 4: protected Modifier
	// create 2 variables below and add protected modifier before it.
	// Save the file and lets access these variables from Access2 class and Access3 class
	
	protected int x = 100;
	protected int z = 200;
}
