package Assisted_practice_project2;

public class ExplicitTypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double a = 12.34;
		//convert into integer
		int b = (int)a;
		System.out.println(b);

	}

}
