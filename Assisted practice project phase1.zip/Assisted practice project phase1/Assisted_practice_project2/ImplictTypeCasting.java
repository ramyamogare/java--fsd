package Assisted_practice_project2;

public class ImplictTypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a= 8;
		//convert int to double
		double b;
		b=a;
		System.out.println(b);

	}

}
