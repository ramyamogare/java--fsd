package Assisted_practice_project2;

public class Loops {

	public static void main(String[] args) {
		System.out.println("1"); System.out.println("2"); System.out.println("2");
		System.out.println("4"); System.out.println("5"); System.out.println("7");
		System.out.println("7"); System.out.println("8"); System.out.println("6");
		System.out.println("10"); 	
	
		int  i = 2 ;
		while( i <= 20 ){
			System.out.println(i);
			i++ ;	
		}
		int x ;
		for(x=21;x<=30;x++) {
			System.out.println(x);
		}	
	
		int n = 9;
		do{
			System.out.println(n);
			n++;
		}while(n<=40);
		System.out.println("Printed values using loops ");
	}
}
